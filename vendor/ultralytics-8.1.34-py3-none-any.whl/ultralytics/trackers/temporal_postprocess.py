# Ultralytics YOLO 🚀, AGPL-3.0 license

from collections import defaultdict, deque

import numpy as np


def _safe_div(x, y, eps=1e-9):
    return x / (y + eps)


def _bbox_iou_xyxy(box1, box2, eps=1e-9):
    x1 = max(box1[0], box2[0])
    y1 = max(box1[1], box2[1])
    x2 = min(box1[2], box2[2])
    y2 = min(box1[3], box2[3])
    iw = max(0.0, x2 - x1)
    ih = max(0.0, y2 - y1)
    inter = iw * ih
    a1 = max(0.0, (box1[2] - box1[0])) * max(0.0, (box1[3] - box1[1]))
    a2 = max(0.0, (box2[2] - box2[0])) * max(0.0, (box2[3] - box2[1]))
    return inter / (a1 + a2 - inter + eps)


class TemporalTrackPostprocessor:
    """Lightweight temporal postprocess for tracked detections."""

    def __init__(
        self,
        enabled=True,
        window_size=5,
        min_hits=2,
        ttl=2,
        conf_low=0.20,
        conf_mid=0.35,
        conf_high=0.55,
        consistency_low=0.35,
        consistency_high=0.60,
        ema_lambda=0.70,
        alpha=0.50,
        beta=0.30,
        gamma=0.20,
        recency_tau=2.0,
    ):
        self.enabled = bool(enabled)
        self.window_size = max(1, int(window_size))
        self.min_hits = max(1, int(min_hits))
        self.ttl = max(0, int(ttl))
        self.conf_low = float(conf_low)
        self.conf_mid = float(conf_mid)
        self.conf_high = float(conf_high)
        self.consistency_low = float(consistency_low)
        self.consistency_high = float(consistency_high)
        self.ema_lambda = float(ema_lambda)
        self.alpha = float(alpha)
        self.beta = float(beta)
        self.gamma = float(gamma)
        self.recency_tau = max(1e-3, float(recency_tau))

        self.states = defaultdict(self._new_state)

    def _new_state(self):
        return {
            "hits": 0,
            "missing": 0,
            "consistency": 1.0,
            "history": deque(maxlen=self.window_size),
            "last_box": None,
        }

    def reset(self):
        self.states.clear()

    def _consistency_score(self, state, box):
        prev = state["last_box"]
        if prev is None:
            return 1.0

        iou_term = _bbox_iou_xyxy(box, prev)

        ctr = np.array([(box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5], dtype=np.float32)
        ctr_prev = np.array([(prev[0] + prev[2]) * 0.5, (prev[1] + prev[3]) * 0.5], dtype=np.float32)
        dist = float(np.linalg.norm(ctr - ctr_prev))
        diag = max(1.0, np.linalg.norm(np.array([box[2] - box[0], box[3] - box[1]], dtype=np.float32)))
        move_term = float(np.exp(-dist / diag))

        area = max(1.0, float((box[2] - box[0]) * (box[3] - box[1])))
        area_prev = max(1.0, float((prev[2] - prev[0]) * (prev[3] - prev[1])))
        scale_term = float(np.exp(-abs(np.log(_safe_div(area, area_prev)))))

        s_raw = 0.5 * iou_term + 0.3 * move_term + 0.2 * scale_term
        return float(self.ema_lambda * state["consistency"] + (1.0 - self.ema_lambda) * s_raw)

    def _gate_decision(self, conf, consistency, hits):
        if hits < self.min_hits:
            return False
        if conf >= self.conf_high:
            return True
        if conf >= self.conf_mid and consistency >= self.consistency_high:
            return True
        if conf <= self.conf_low and consistency <= self.consistency_low:
            return False
        return consistency >= self.consistency_high

    def _fuse_track(self, state, fallback_row):
        hist = list(state["history"])
        if len(hist) == 1:
            return fallback_row

        n = len(hist)
        boxes = np.array([h["box"] for h in hist], dtype=np.float32)
        confs = np.array([h["conf"] for h in hist], dtype=np.float32)
        cls_vals = np.array([h["cls"] for h in hist], dtype=np.float32)
        c_vals = np.array([h["cons"] for h in hist], dtype=np.float32)
        recency = np.array([np.exp(-(n - 1 - i) / self.recency_tau) for i in range(n)], dtype=np.float32)

        weights = self.alpha * confs + self.beta * recency + self.gamma * c_vals
        wsum = float(weights.sum())
        if wsum <= 1e-9:
            return fallback_row
        weights /= wsum

        fused_box = (boxes * weights[:, None]).sum(axis=0)
        fused_conf = float((confs * weights).sum())
        mean_cons = float((c_vals * weights).sum())
        fused_conf = float(np.clip(fused_conf * (0.5 + 0.5 * mean_cons), 0.0, 1.0))

        # Weighted class vote. This keeps class stable when short-lived outliers appear.
        class_score = defaultdict(float)
        for cls_v, w in zip(cls_vals, weights):
            class_score[int(cls_v)] += float(w)
        fused_cls = float(max(class_score.items(), key=lambda kv: kv[1])[0])

        out = fallback_row.copy()
        out[:4] = fused_box
        out[5] = fused_conf
        out[6] = fused_cls
        return out

    def process(self, tracks):
        """
        Args:
            tracks (np.ndarray): shape (N, 8), each row is
                [x1, y1, x2, y2, track_id, conf, cls, det_idx]
        """
        if not self.enabled or len(tracks) == 0:
            return tracks

        tracks = tracks.astype(np.float32, copy=True)
        current_ids = set()
        kept = []

        for row in tracks:
            track_id = int(row[4])
            current_ids.add(track_id)
            state = self.states[track_id]

            box = row[:4].copy()
            conf = float(row[5])
            cls = float(row[6])

            cons = self._consistency_score(state, box)
            state["consistency"] = cons
            state["hits"] += 1
            state["missing"] = 0
            state["last_box"] = box
            state["history"].append({"box": box, "conf": conf, "cls": cls, "cons": cons})

            if not self._gate_decision(conf, cons, state["hits"]):
                continue

            kept.append(self._fuse_track(state, row))

        stale_ids = []
        for track_id, state in self.states.items():
            if track_id in current_ids:
                continue
            state["missing"] += 1
            if state["missing"] > self.ttl:
                stale_ids.append(track_id)
        for track_id in stale_ids:
            self.states.pop(track_id, None)

        if not kept:
            return np.empty((0, tracks.shape[1]), dtype=np.float32)
        return np.stack(kept, axis=0).astype(np.float32, copy=False)
